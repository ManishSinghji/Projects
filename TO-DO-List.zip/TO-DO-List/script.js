// Get references to HTML elements
const taskInput = document.getElementById("taskInput");
const taskList = document.getElementById("taskList");

// Function to add a new task
function addTask() {
    const taskText = taskInput.value.trim();

    if (taskText === "") {
        return;
    }

    // Create a new list item
    const listItem = document.createElement("li");
    listItem.innerHTML = `
        ${taskText}
        <button class="edit-button" onclick="editTask(this)">Edit</button>
        <button class="delete-button" onclick="deleteTask(this)">Delete</button>
    `;

    // Add the new item to the task list
    taskList.appendChild(listItem);

    // Clear the input field
    taskInput.value = "";
}

// Function to delete a task
function deleteTask(button) {
    const listItem = button.parentElement;
    taskList.removeChild(listItem);
}

// Function to edit a task
function editTask(button) {
    const listItem = button.parentElement;
    const taskText = listItem.firstChild.textContent;

    const updatedText = prompt("Edit task:", taskText);

    if (updatedText !== null) {
        listItem.firstChild.textContent = updatedText;
    }
}
